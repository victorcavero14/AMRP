
public enum TiposNodos {
	NODODOS, NODOTRES, NODOCUATRO
}